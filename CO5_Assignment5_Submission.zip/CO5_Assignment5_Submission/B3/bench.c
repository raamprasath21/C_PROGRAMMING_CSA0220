#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

typedef struct { int id; char name[32]; char group[4]; int age; char phone[16]; int last_donation; } Donor;

static double med3(double a, double b, double c) { double m = fmin(a, b); return fmax(m, fmin(fmax(a, b), c)); }
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

static void make(Donor *d, int i)
{
 d->id = 1000 + i;
 snprintf(d->name, sizeof d->name, "Donor%07d", i);
 strcpy(d->group, (i % 2) ? "O+" : "A-");
 d->age = 18 + i % 47;
 snprintf(d->phone, sizeof d->phone, "9%09d", i);
 d->last_donation = 20000 + i % 365;
}

static long fsize(const char *path) { FILE *f = fopen(path, "rb"); fseek(f, 0, SEEK_END); long n = ftell(f); fclose(f); return n; }

/* text format: one donor per line, fields separated by '|' */
static void text_write(const char *path, int n)
{
 FILE *f = fopen(path, "w"); Donor d;
 for (int i = 0; i < n; i++) { make(&d, i);
 fprintf(f, "%d|%s|%s|%d|%s|%d\n", d.id, d.name, d.group, d.age, d.phone, d.last_donation); }
 fclose(f);
}
static int text_read_all(const char *path, Donor *out, int cap)
{
 FILE *f = fopen(path, "r"); int n = 0;
 while (n < cap && fscanf(f, "%d|%31[^|]|%3[^|]|%d|%15[^|]|%d\n", &out[n].id, out[n].name,
 out[n].group, &out[n].age, out[n].phone, &out[n].last_donation) == 6) n++;
 fclose(f); return n;
}
static void bin_write(const char *path, int n)
{
 FILE *f = fopen(path, "wb"); Donor d;
 for (int i = 0; i < n; i++) { make(&d, i); fwrite(&d, sizeof d, 1, f); }
 fclose(f);
}
static int bin_read_all(const char *path, Donor *out, int cap)
{
 FILE *f = fopen(path, "rb"); int n = fread(out, sizeof(Donor), cap, f); fclose(f); return n;
}

static int update_bin(const char *path, int idx, int age)
{
 FILE *f = fopen(path, "r+b"); Donor d;
 if (!f) return 0;
 fseek(f, (long)idx * sizeof(Donor), SEEK_SET);
 if (fread(&d, sizeof d, 1, f) != 1) { fclose(f); return 0; }
 d.age = age;
 fseek(f, -(long)sizeof(Donor), SEEK_CUR);
 fwrite(&d, sizeof d, 1, f);
 fclose(f); return 1;
}
static int update_text(const char *path, Donor *buf, int n, int idx, int age)
{
 /* text has no fixed record size: read everything, change one line, rewrite everything */
 n = text_read_all(path, buf, n);
 buf[idx].age = age;
 FILE *f = fopen(path, "w");
 for (int i = 0; i < n; i++)
 fprintf(f, "%d|%s|%s|%d|%s|%d\n", buf[i].id, buf[i].name, buf[i].group, buf[i].age, buf[i].phone, buf[i].last_donation);
 fclose(f); return 1;
}

int main(void)
{
 const char *TF = "donors.txt", *BF = "donors.bin";
 int sizes[] = {1000, 10000, 100000};
 Donor *buf = malloc(sizeof(Donor) * 100000);

 printf("B3.1 correctness, 10 records\n");
 bin_write(BF, 10); text_write(TF, 10);
 Donor a[10], b[10];
 int na = bin_read_all(BF, a, 10), nb = text_read_all(TF, b, 10);
 int same = na == 10 && nb == 10;
 for (int i = 0; i < 10 && same; i++)
 same = a[i].id == b[i].id && !strcmp(a[i].name, b[i].name) && !strcmp(a[i].group, b[i].group)
 && a[i].age == b[i].age && !strcmp(a[i].phone, b[i].phone) && a[i].last_donation == b[i].last_donation;
 printf(" binary read %d, text read %d, identical: %s\n\n", na, nb, same ? "YES" : "NO");

 printf("B3.2 size and write/read time (median of 3 runs)\n");
 printf(" %-8s %-12s %-12s %-12s %-12s %-12s %-12s\n", "donors", "txt bytes", "bin bytes", "txt write", "txt read", "bin write", "bin read");
 for (int s = 0; s < 3; s++) {
 int n = sizes[s]; double tw[3], tr[3], bw[3], br[3];
 for (int r = 0; r < 3; r++) {
 double t0 = now(); text_write(TF, n); tw[r] = now() - t0;
 t0 = now(); text_read_all(TF, buf, n); tr[r] = now() - t0;
 t0 = now(); bin_write(BF, n); bw[r] = now() - t0;
 t0 = now(); bin_read_all(BF, buf, n); br[r] = now() - t0;
 }
 printf(" %-8d %-12ld %-12ld %-12.4f %-12.4f %-12.4f %-12.4f\n", n, fsize(TF), fsize(BF),
 med3(tw[0],tw[1],tw[2]), med3(tr[0],tr[1],tr[2]), med3(bw[0],bw[1],bw[2]), med3(br[0],br[1],br[2]));
 }
 printf("\nB3.3 update the 50,000th record (index 49999), median of 5 runs\n");
 bin_write(BF, 100000); text_write(TF, 100000);
 double ub[5], ut[5];
 for (int r = 0; r < 5; r++) {
 double t0 = now(); update_bin(BF, 49999, 40 + r); ub[r] = now() - t0;
 t0 = now(); update_text(TF, buf, 100000, 49999, 40 + r); ut[r] = now() - t0;
 }
 /* sort tiny arrays for median */
 for (int i = 0; i < 5; i++) for (int j = i + 1; j < 5; j++) {
 if (ub[j] < ub[i]) { double t = ub[i]; ub[i] = ub[j]; ub[j] = t; }
 if (ut[j] < ut[i]) { double t = ut[i]; ut[i] = ut[j]; ut[j] = t; } }
 printf(" binary in-place (fseek): %.6f s\n", ub[2]);
 printf(" text full rewrite      : %.6f s\n", ut[2]);
 Donor chk; FILE *f = fopen(BF, "rb"); fseek(f, 49999L * sizeof(Donor), SEEK_SET); if (fread(&chk, sizeof chk, 1, f) != 1) return 1; fclose(f);
 printf(" verify binary record 49999 age = %d (expected 44)\n", chk.age);
 free(buf);
 return 0;
}
