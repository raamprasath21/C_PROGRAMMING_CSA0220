#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>

#define TODAY 20400          /* report date as day number */
#define WINDOW 7             /* "next week" */
#define DONATION_GAP 56      /* days between whole-blood donations */

typedef struct { int id; char group[4]; int age; int last_donation; } Donor;
typedef struct { Donor *data; int size, capacity; } DonorList;

static int add_donor(DonorList *list, const Donor *d)
{
 if (list->size == list->capacity) {
 int new_cap = list->capacity ? list->capacity * 2 : 2;
 Donor *p = realloc(list->data, (size_t)new_cap * sizeof(Donor));
 if (p == NULL) return 0;
 list->data = p; list->capacity = new_cap;
 }
 list->data[list->size++] = *d;
 return 1;
}

static int eligible_in_window(const Donor *d)
{
 return d->age >= 18 && d->age <= 65 && d->last_donation + DONATION_GAP <= TODAY + WINDOW;
}

static double secs(struct timespec a, struct timespec b) { return (b.tv_sec - a.tv_sec) + (b.tv_nsec - a.tv_nsec) * 1e-9; }
static long rss_kb(void) { struct rusage u; getrusage(RUSAGE_SELF, &u); return u.ru_maxrss; }

static void generate(const char *path, int n)
{
 FILE *f = fopen(path, "wb");
 if (!f) { perror(path); exit(1); }
 for (int i = 0; i < n; i++) {
 Donor d; d.id = 100000 + i; snprintf(d.group, sizeof d.group, "%s", (i % 2) ? "O+" : "A-");
 d.age = 16 + i % 60; d.last_donation = 20000 + (i * 37) % 400;
 fwrite(&d, sizeof d, 1, f);
 }
 fclose(f);
}

int main(int argc, char *argv[])
{
 if (argc < 3) { fprintf(stderr, "usage: %s gen N file | load file | stream file\n", argv[0]); return 2; }
 if (strcmp(argv[1], "gen") == 0) { generate(argv[3], atoi(argv[2])); printf("generated %s\n", argv[3]); return 0; }
 const char *path = argv[2];
 FILE *f = fopen(path, "rb");
 if (!f) { perror(path); return 1; }
 struct timespec t0, t1; clock_gettime(CLOCK_MONOTONIC, &t0);
 long total = 0, eligible = 0;

 if (strcmp(argv[1], "load") == 0) {
 DonorList list = {NULL, 0, 0};
 Donor d;
 while (fread(&d, sizeof d, 1, f) == 1) {
 if (!add_donor(&list, &d)) { fprintf(stderr, "out of memory\n"); fclose(f); free(list.data); return 1; }
 }
 total = list.size;
 for (int i = 0; i < list.size; i++) eligible += eligible_in_window(&list.data[i]);
 free(list.data);
 } else { /* stream: fixed 1-record buffer, constant memory */
 Donor d;
 while (fread(&d, sizeof d, 1, f) == 1) { total++; eligible += eligible_in_window(&d); }
 }
 fclose(f);
 clock_gettime(CLOCK_MONOTONIC, &t1);
 printf("mode=%s donors=%ld eligible_next_%d_days=%ld time=%.4f s peak_rss=%ld KB\n",
 argv[1], total, WINDOW, eligible, secs(t0, t1), rss_kb());
 return 0;
}
