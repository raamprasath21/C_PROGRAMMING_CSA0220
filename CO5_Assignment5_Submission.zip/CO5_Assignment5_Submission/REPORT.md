# CO5 Assignment 5 – Modular, Memory-Aware and Persistent Program Engineering
District Blood Bank Network

## 0. Scope, environment and deviations

- **Pseudocode convention.** The SIMATS Engineering Standard for Algorithmic Pseudocode was not provided with the assignment. The pseudocode below uses a conventional style (`FUNCTION`, `IF … THEN … ENDIF`, `WHILE … ENDWHILE`, `RETURN`, `←` for assignment). Please replace it with the SIMATS notation if it differs.
- **Memory checking.** Valgrind is not installed in the build environment, so every memory check uses AddressSanitizer, UndefinedBehaviorSanitizer and LeakSanitizer (`-fsanitize=address,undefined`). Those tools cover the same error classes (invalid reads and writes, leaks, double free), but the valgrind output required by B2 and B4.2 has not been produced.
- **Permission test.** The first read-only test ran as root, which ignores file permissions. It was rerun as user `nobody`, and that result is the one reported.
- **GitHub repository.** I cannot create a repository or take screenshots from here. The folder `CO5_Assignment5_Submission/` contains the source for every task, a README, and this report, ready to push. Run commands are in the README.
- **Timings.** Absolute times depend on the machine. Scaling trends and call counts do not.
- **Donor record.** The B4 report stores `id`, `group`, `age` and `last_donation`. The given `Donor` struct holds only `id` and `group`, so the report program uses an extended struct and the same growable-list logic. The TODO file keeps the given struct.
- **Eligibility rule (assumed).** A donor is eligible in the next 7 days if age is 18–65 and the last donation was at least 56 days before the end of that window. The case study does not define the rule, so this is an assumption.

---

# PART A – Design & Pseudocode

## A1 – Decompose the program into functions

### A1.1 Structure chart

```
main
├── cmd_register
│   ├── read_donor_input
│   ├── is_valid_group
│   ├── add_donor
│   └── save_donors
├── cmd_find
│   ├── load_donors
│   ├── find_eligible          (returns summary, see A1.3)
│   │   └── is_eligible
│   └── print_donors
├── cmd_issue
│   ├── load_stock
│   ├── lowest_stock           (A3.2, used by stock report)
│   ├── update_units
│   └── save_stock
└── cmd_report                 (B4)
    ├── load_donors  ─or─  stream_donors
    └── is_eligible

Leaf utilities (no file I/O, no globals):
    digital_root, power_fast, check_digit_ok, is_valid_group
```

Each command calls a small number of functions. The leaves hold no state, so they can be tested in isolation.

### A1.2 Interface design: prototypes with parameter passing decisions

```c
int  add_donor(DonorList *list, const Donor *d);
int  load_donors(const char *path, DonorList *list);
int  save_donors(const char *path, const DonorList *list);
int  is_eligible(const Donor *d, int today);
int  is_valid_group(const char *group);
int  update_units(FILE *fp, int index, int units);
int  load_stock(const char *path, Stock stock[], int n);
int *lowest_stock(int stock[], int n);
long long power_fast(long long base, int exp);
int  digital_root(long long n);
```

| Parameter | Decision | Justification |
|---|---|---|
| `DonorList *list` in `add_donor` | pointer, not const | The function changes `data`, `size` and `capacity`. |
| `const Donor *d` in `add_donor` | pointer, const | Read only. A pointer avoids copying the record, and `const` tells the caller it will not change. |
| `const char *path` | pointer, const | A string is passed by address. The function only reads it. |
| `const DonorList *list` in `save_donors` | pointer, const | Saving reads the list and must not modify it. |
| `int today`, `int index`, `int units` | by value | Scalars are cheap to copy and the function has no reason to change the caller's copy. |
| `FILE *fp` in `update_units` | pointer, not const | Reading and writing move the file position, so the stream is modified. |
| `int stock[]` in `lowest_stock` | pointer (array decays), not const | It returns a pointer into this array, so the caller needs write access. |
| `long long base` in `power_fast` | by value | Read only and a single machine word. |

### A1.3 Returning more than one value

The function `find_eligible` must return both the number of eligible donors and the ID of the youngest eligible donor.

**Design 1 – pointer parameters**

```c
int find_eligible_ptr(const DonorList *list, const char *group, int today,
                      int *count, int *youngest_id);
/* returns 1 on success, 0 on bad arguments; count and youngest_id are written through the pointers */
```

**Design 2 – returning a structure**

```c
typedef struct { int count; int youngest_id; } EligibleSummary;
EligibleSummary find_eligible(const DonorList *list, const char *group, int today);
```

**Comparison**

| Criterion | Pointer parameters | Structure return |
|---|---|---|
| Readability | Caller must declare two variables first | One call, one result |
| Error reporting | A return code is free to signal failure | Needs a sentinel (e.g. `count = -1`) |
| Optional outputs | Caller can pass `NULL` for an output it does not need | All fields are always produced |
| Cost | Two pointer writes | Two ints, returned in registers on common ABIs; no measurable difference here |
| Extending | Adding a third output changes the signature | Adding a field is backward compatible |

**Decision:** structure return. Both outputs are always needed, the struct keeps them together, and it extends without changing the signature. Pointer parameters would be preferred if the function also needed a separate status code.

### Alternative concept: global variables

If `find_eligible` read the list from a global `donors` and wrote the result to global `g_count` and `g_youngest`:

- **Running time** is essentially unchanged. Each access goes through a fixed address instead of a parameter register, which is negligible for a scan over `n` donors.
- **Memory** changes little. Globals occupy static storage for the whole program life, whereas parameters use stack space only during the call. For two ints this difference is trivial.
- **Coupling** rises sharply. Every function that touches a global depends on that hidden state, and the call order matters.
- **Testing** suffers. Each test must reset every global before running, and two test cases cannot run side by side.
- **Reuse** is blocked. The report program cannot hold two donor lists at once (for example, the full list and a filtered one), because both would have to share the same global.

The parameter version is preferred for these reasons. The cost is nothing measurable, while the benefit is that each function's behaviour depends only on its inputs.

---

## A2 – Design with recursion

### A2.1 Recursive pseudocode

**Digital root.** The check digit is the digital root of the other digits.

```
FUNCTION digit_sum(n)                  // helper, recursive
  IF n < 10 THEN RETURN n                      // base case
  RETURN (n MOD 10) + digit_sum(n DIV 10)      // recursive case
END

FUNCTION digital_root(n)
  IF n < 10 THEN RETURN n                      // base case: already one digit
  RETURN digital_root(digit_sum(n))            // recursive case
END
```

Base case: `n < 10`, which is already a single digit. Recursive case: replace `n` by the sum of its digits, which is smaller, so the recursion ends.

**Power by halving.** Using `base^n = (base^(n/2))²`, and a factor of `base` when `n` is odd.

```
FUNCTION power(base, n)
  IF n = 0 THEN RETURN 1                       // base case
  half ← power(base, n DIV 2)                  // recursive case: computed ONCE
  IF n MOD 2 = 0 THEN RETURN half * half
  RETURN base * half * half
END
```

Base case: `n = 0`. Recursive case: the exponent halves on each call.

### A2.2 Trace the calls

**Digital root of 9875.** Check digit = 1 + (9875 − 1) MOD 9 = 2, which the trace should confirm.

```
digital_root(9875)            digit_sum(9875) = 29
  digital_root(29)            digit_sum(29)   = 11
    digital_root(11)          digit_sum(11)   = 2
      digital_root(2)  ← base case, returns 2   ← deepest point
    returns 2
  returns 2
returns 2
```

Stack at the deepest point (`digital_root(2)` running):

```
| digital_root(2)   |  top
| digital_root(11)  |
| digital_root(29)  |
| digital_root(9875)|  bottom (main's frame below)
```

**Power, halving, `power(2, 10)`.** Result 1024.

```
power(2,10) → power(2,5) → power(2,2) → power(2,1) → power(2,0)  ← base, returns 1
power(2,1) = 2 * 1 * 1 = 2
power(2,2) = 2 * 2     = 4
power(2,5) = 2 * 4 * 4 = 32
power(2,10)= 32 * 32   = 1024
```

Stack depth at the deepest point: 5 frames.

**Recurrences for call counts**

- Linear: `L(n) = L(n − 1) + 1`, `L(0) = 1`, which gives **L(n) = n + 1**.
- Halving: `H(n) = H(⌊n/2⌋) + 1`, `H(0) = 1`, which gives **H(n) = ⌊log₂ n⌋ + 2** for n ≥ 1.

### A2.3 Recursion risks

**Missing base case.** Without the `n = 0` (or `n < 10`) test, every call makes another call, so the stack grows until it overflows and the process is killed with a segmentation fault. The call graph never terminates, and the program produces no output. This is the most common recursion bug.

**When to replace recursion with a loop.**

- The depth grows with the input (linear power with a large exponent), so the stack limit becomes a real bound. Section B1.4 measures it.
- The language does not guarantee tail-call optimisation, which C does not, so recursion depth cannot be relied on to stay constant.
- The loop is equally clear, as with square-and-multiply.

Recursion is acceptable when the depth is provably small and the structure is naturally recursive, as with the digital root (at most about 3 levels for any donor-sized number) or with divide-and-conquer.

### Alternative concept: digital root by loop or by formula

- **Loop:** `WHILE n ≥ 10: n ← digit_sum(n)`. Time is proportional to the number of digits per pass, and the number of passes is small, so about O(d) time for d digits. Space is O(1).
- **Formula:** `1 + (n − 1) MOD 9` for n > 0 (and 0 for n = 0). Time O(1) and space O(1), since it is one arithmetic expression. It is not useful as a check on how the sum is computed, but it is correct and fastest.
- **Recursion:** O(d) time and O(d) stack space, because the frames are live at the same time. For digital roots, d is at most about 3 for donor IDs.

The formula is best for production. Recursion is best for showing the decomposition in a teaching setting.

---

## A3 – Design with pointers

### A3.1 Pointer operations on `int stock[8]` with `int *p = stock;`

| Expression | Meaning | Value (example stock = {12, 40, 25, 8, 30, 5, 18, 22}) |
|---|---|---|
| `p + 3` | address of `stock[3]` (3 elements further, not 3 bytes) | address `&stock[3]` |
| `*(p + 3)` | value at that address | 8 |
| `p[3]` | same as `*(p + 3)` | 8 |
| `*p++` | `*p` is used first (`stock[0]`), then `p` moves to `stock[1]` | 12, and `p` now points to `stock[1]` |

Memory diagram (addresses increase to the right, each `int` is 4 bytes):

```
index      0     1     2     3     4     5     6     7
value     12    40    25     8    30     5    18    22
address  A+0   A+4   A+8  A+12  A+16  A+20  A+24  A+28
           ↑                  ↑
           p (before *p++)    p + 3 → A+12
After *p++, p = A+4 (points at stock[1]).
```

### A3.2 Returning a pointer to the lowest-stock element

```c
int *lowest_stock(int stock[], int n)
{
 int *best = stock;               /* pointer to the first element */
 for (int i = 1; i < n; i++)
 if (stock[i] < *best)
 best = &stock[i];
 return best;                     /* points into the caller's array */
}

/* caller */
*lowest_stock(stock, 8) += 5;     /* updates the element directly */
```

**Why returning a pointer to a local variable is wrong.** A local variable lives in the function's stack frame. When the function returns, that frame is released, and the pointer refers to memory that may be reused by the next call. The caller then has a dangling pointer, and reading or writing through it is undefined behaviour. The function above is safe because it returns an address inside `stock`, which the caller owns and which outlives the call.

### A3.3 Command-line interface

```
bloodbank register
bloodbank find <group>           e.g. bloodbank find O+
bloodbank issue <group> <units>  e.g. bloodbank issue A+ 2
bloodbank report
```

- `argc` must match the command: `find` expects `argc == 3`, `issue` expects `argc == 4`.
- `argv[1]` is checked against the known commands.
- `argv[2]` is checked against the eight valid groups (`A+ A- B+ B- AB+ AB- O+ O-`).
- Invalid arguments print a usage message to `stderr` and exit with status **2**. File and runtime errors exit with status **1**, and success exits with **0**.

### Alternative concept: return an index instead of a pointer

```c
int lowest_index(const int stock[], int n);

/* caller */
int i = lowest_index(stock, 8);
stock[i] += 5;
```

- **Time** O(n), identical to the pointer version: one scan.
- **Space** O(1) in both versions.
- **Safety after reallocation.** A pointer into a dynamically allocated array becomes dangling if `realloc` moves the block, and the caller must remember to refresh it. An index stays valid because it is relative to the array's start. For this reason an index is safer whenever the array may grow.

The pointer version is more direct for a fixed array. The index version is preferred for any array that can grow.

---

## A4 – Design dynamic memory use

### A4.1 Growable donor list with safe `realloc`

```
FUNCTION add_donor(list, donor) RETURNS BOOLEAN
  IF list.size = list.capacity THEN
    IF list.capacity = 0 THEN new_cap ← 2 ELSE new_cap ← 2 * list.capacity
    tmp ← REALLOC(list.data, new_cap * SIZE_OF(Donor))
    IF tmp = NULL THEN
      RETURN FALSE            // list.data is still valid: nothing was lost
    ENDIF
    list.data ← tmp
    list.capacity ← new_cap
  ENDIF
  list.data[list.size] ← donor
  list.size ← list.size + 1
  RETURN TRUE
END
```

**Why `realloc` goes into `tmp`.** If `realloc` fails it returns `NULL` and leaves the original block untouched. Writing the result straight into `list->data` would overwrite the only pointer to that block with `NULL`, causing a leak and losing every donor already stored.

### A4.2 Three memory errors

**Memory leak.** A block is allocated and the last pointer to it is lost, so it is never freed.
- Example: `list->data = realloc(list->data, n)` returns `NULL` on failure, which overwrites the only pointer to the old block.
- Prevention: the `tmp` pattern above, plus a single `free_list` function that frees the array and clears the pointer.

**Dangling pointer.** A pointer still refers to memory that has been freed or moved.
- Example: a caller stores `Donor *first = &list.data[0];`, then adds more donors. `realloc` moves the block, and `first` now points to freed memory.
- Prevention: store indices, not pointers, across calls that can grow the list, and fetch the pointer again after every `add_donor`.

**Double free.** `free` is called twice on the same block.
- Example: two structures hold a copy of `list.data`, and both are freed at shutdown.
- Prevention: each block has one owner. `free_list` sets `list->data = NULL` after freeing, so a second call is harmless (`free(NULL)` is a no-op).

### Alternative concept: grow by a fixed 10 records

```
FUNCTION add_donor_fixed(list, donor)
  IF list.size = list.capacity THEN list.capacity ← list.capacity + 10 … REALLOC
```

Growing by a fixed increment `k` copies about `n²/(2k)` elements in total for n insertions. Doubling copies fewer than `2n`. Measured with the counting simulation, with `k = 10`:

| n | Doubling: elements copied | Doubling: reallocs | Fixed +10: elements copied | Fixed +10: reallocs |
|---|---|---|---|---|
| 1,000 | 1,022 | 10 | 49,500 | 100 |
| 10,000 | 16,382 | 14 | 4,995,000 | 1,000 |
| 100,000 | 131,070 | 17 | 499,950,000 | 10,000 |

- **Total copies:** fixed +10 is O(n²) (about n²/20). Doubling is O(n), since the copies form a geometric series (about 1.3n here).
- **Maximum unused space:** with +10 it is at most 9 slots. With doubling it can approach n (just after a doubling, about half the array is empty). This is the cost of doubling, and it is acceptable because the amortised insertion time is O(1).

---

## A5 – Design the file storage

### A5.1 Text or binary?

**Donor file (text, `fprintf`).** One donor per line, fields separated by `|`.
- Names and phone numbers are variable-length strings, which fit a text line naturally.
- Donors are read in full for each report or search (a sequential scan), so random access by position is not needed.
- The file is readable and editable by hand, which helps with recovery and auditing.
- Cost: parsing is slower than a binary read, and the file is larger for numbers.

**Stock file (binary, `fwrite`).** Fixed-size records of a blood group code and a unit count.
- Every record has the same size, so record `k` starts at byte `k * sizeof(Stock)` and can be reached with `fseek`.
- Updates touch one record and never rewrite the file.
- Cost: not human-readable, and not portable between machines with different byte order or struct padding (see B3.4).

### A5.2 Update in place with `fseek`, `fread` and `fwrite`

```
FUNCTION update_units(fp, index, units) RETURNS BOOLEAN
  IF fseek(fp, index * SIZE_OF(Stock), SEEK_SET) ≠ 0 THEN RETURN FALSE
  IF fread(s, SIZE_OF(Stock), 1, fp) ≠ 1 THEN RETURN FALSE    // beyond end of file
  s.units ← units
  IF fseek(fp, -SIZE_OF(Stock), SEEK_CUR) ≠ 0 THEN RETURN FALSE
  IF fwrite(s, SIZE_OF(Stock), 1, fp) ≠ 1 THEN RETURN FALSE
  RETURN TRUE
END
```

The `fseek` back by one record is needed because `fread` advanced the position. The C standard also requires a positioning call between a read and a write on the same stream.

**Why this is difficult for the text file.** Lines have different lengths, so the offset of record `k` is not known in advance. Finding it means scanning from the start. Changing a line to a different length (for example, `12` becomes `120`) shifts everything after it, so the whole remainder of the file must be rewritten.

### Alternative concept: text stock file with full rewrite

- **Time per update:** O(n) for the text version, because the file is read and rewritten. O(1) for the binary version, because one record is seeked and written.
- **File size:** text uses roughly 6–8 bytes per record for `A+ 40\n` style lines, and grows with the number of digits. The binary `Stock` record used here is 8 bytes (two ints), which is fixed.

Measured in B3.3 for donor records: 100,000 donors take about 35 ms to rewrite in text, against about 16 µs for a binary in-place update, roughly 2,000 times faster.

---

# PART B – Implementation & Experimental Investigation

## B1 – Recursive functions

### B1.1 Validation

`power_fast` was completed with the base case `exp == 0`, one recursive call stored in `half`, and an extra factor of `base` for odd exponents. The file `B1/b1_power.c` reproduces the expected output exactly:

```
linear: 1073741824 in 31 calls
fast : 1073741824 in 6 calls
```

Validation tests (`B1/b1_experiments.c`), all passed:

| Test | Input | Verifies |
|---|---|---|
| Ordinary, even exponent | 2^10 = 1024 | Basic halving and squaring |
| Ordinary, odd exponent | 3^5 = 243 | The extra `base` factor for odd `n` |
| Zero exponent | 0^0 = 1 | Base case `exp == 0` is reached first |
| Zero base | 0^7 = 0 | Multiplication by zero propagates |
| Unit base | 1^(large) = 1 | Results do not drift with repeated squaring |
| Exponent 1 | 7^1 = 7 | Recursion through `exp / 2 = 0` with an odd exponent |
| Mixed bits | 5^13 = 1220703125 | Correct combination of several odd and even steps |

### B1.2 Comparison with Part A pseudocode

The pseudocode in A2.1 matches the code, with one addition. In C the odd-exponent multiplication is written after the even check (`if (exp % 2 == 0) return half * half; return base * half * half;`), which is equivalent. The only real change is the variable `half`, which stores the single recursive result so it is not computed twice. The "two calls" variant in B1.3 shows what happens when that change is undone.

### B1.3 Call counts

Exponent `n`, base 1 to avoid overflow:

| n | Linear calls | Halving calls | Halving with two calls (`half*half` replaced) | Recurrence check |
|---|---|---|---|---|
| 10 | 11 | 5 | 31 | L = n+1 = 11; H = ⌊log₂10⌋+2 = 5 |
| 100 | 101 | 8 | 255 | L = 101; H = 6+2 = 8 |
| 1,000 | 1,001 | 11 | 2,047 | L = 1001; H = 9+2 = 11 |
| 10,000 | 10,001 | 15 | 32,767 | L = 10001; H = 13+2 = 15 |

The measured counts match both recurrences exactly.

**Two-call variant and why it matters.** `power_fast(2, 30)` with `power_fast(base, exp/2) * power_fast(base, exp/2)` gives 1,073,741,824 correctly, but in **63 calls** instead of 6. The two recursive calls each recompute the same subproblem, so the call tree doubles at every level: `T(n) = 2T(n/2) + 1`, which solves to about `2^(log₂ n) = n`. The algorithm therefore becomes O(n) calls, the same as the linear version, and loses its advantage. The lesson is that a recursive call must be stored and reused, not repeated.

### B1.4 Recursion limit

`power_linear` was compiled at `-O0` and run with increasing exponents on an 8 MB stack (`ulimit -s` = 8192 KB), using a binary search over the exponent:

- Largest exponent that succeeds: **261,968**.
- First exponent that crashes: **261,969**, with exit code 139 (SIGSEGV).

The crash is a stack overflow. 8 MB divided by about 262,000 frames is about **32 bytes per frame**, which is consistent with a small frame holding the parameters and return address. The iterative square-and-multiply version has no recursion. It returns the correct result for exponents up to `INT_MAX` (for example 2,000,000,000) using a loop of about 31 iterations, so the stack limit does not apply.

## B2 – Adversarial inputs

### Test 1: name longer than the buffer – `scanf("%s")` vs `fgets`

Buffer: `char name[16]`. Input: a 36-character name.

| Version | Result |
|---|---|
| `scanf("%s", name)`, normal build | Program aborts: `*** stack smashing detected ***`, exit code 134 |
| `scanf("%s", name)`, AddressSanitizer | `stack-buffer-overflow`: `WRITE of size 37` into the 16-byte buffer, reported at `name_scanf.c:4` |
| `fgets(name, sizeof name, stdin)` | Stores `AnastasiaVenkat` (15 characters plus `\0`), reports the truncation, and drains the rest of the line. Exit 0. |

**Explanation.** `%s` writes the whole word and the terminating `\0`, with no limit. For a 36-character name it writes 37 bytes into a 16-byte buffer. The 21 extra bytes overwrite adjacent stack data (which can include the saved return address), so the stack protector detects the corruption and aborts. I did not inspect the exact frame layout, so the claim about which data is overwritten is an inference from the protector's abort. `fgets` takes the buffer size as a limit and stops early. Because the line is longer than the buffer, the newline is absent, so the program reads and discards the remaining characters. Without that draining step the leftover text would be read by the next input call.

### Test 2: missing or read-only data file, reported with `perror`

| Case | Command result |
|---|---|
| Missing file | `/nonexistent/stock.dat: No such file or directory`, exit 1 |
| Read-only file, run as `nobody` | `/tmp/ro_stock.dat: Permission denied`, exit 1 |

The program checks the return value of `fopen` and calls `perror`, which prints the system error text. It exits cleanly instead of dereferencing `NULL`. As root the read-only file opens, because root bypasses permission bits, so the test had to be repeated as a normal user.

### Test 3: command-line arguments

| Invocation | Output | Exit |
|---|---|---|
| `bloodbank_cli` (no arguments) | usage message | 2 |
| `bloodbank_cli find O+ extra` (too many) | usage message | 2 |
| `bloodbank_cli find C+` (invalid group) | `error: invalid blood group 'C+'` | 2 |
| `bloodbank_cli donate O+` (unknown command) | `error: unknown command 'donate'` | 2 |
| `bloodbank_cli issue AB-` (valid) | `command=issue group=AB-` | 0 |

### Memory checks

- `update_units` and `add_donor` were run with `-fsanitize=address,undefined`: no errors and no leaks reported.
- The B4 report was run under LeakSanitizer in both modes: no leaks.
- Valgrind output (requested) was not produced because valgrind is not installed here. The sanitizers detect the same classes of error, but a valgrind run is still recommended on the student's machine.

## B3 – Text file vs binary file

### B3.1 Correctness on small data

Ten donor records were written to a text file and a binary file and read back. Both returned all ten records, and every field matched (`identical: YES`).

### B3.2 Size and time at three scales

Median of three runs, `donor` records as defined in `bench.c`:

| Donors | Text bytes | Binary bytes | Text write (s) | Text read (s) | Binary write (s) | Binary read (s) |
|---|---|---|---|---|---|---|
| 1,000 | 41,000 | 64,000 | 0.0003 | 0.0002 | 0.0002 | 0.0000 |
| 10,000 | 411,000 | 640,000 | 0.0025 | 0.0020 | 0.0012 | 0.0000 |
| 100,000 | 4,192,000 | 6,400,000 | 0.0239 | 0.0198 | 0.0118 | 0.0009 |

**Interpretation.** The binary file here is larger, because the record is fixed at 64 bytes with padded `name` and `phone` fields. The text file is smaller because each line stores only the characters it needs. The binary file is faster to write and read by about 2× to 20×, because it avoids formatting and parsing. Binary read time is near zero here because the operating system caches the file, so the figure reflects memory copying more than disk I/O.

### B3.3 Update one record

Record 50,000 (index 49,999) of the 100,000-donor file, median of five runs:

| Method | Time |
|---|---|
| Binary, in place (`fseek`, `fread`, `fseek`, `fwrite`) | 0.000016 s |
| Text, full rewrite | 0.035184 s |

The binary update is about 2,000 times faster. The verification step confirmed the updated record reads back correctly. The text method is O(n) per update and the binary method is O(1).

### B3.4 Engineering trade-off

- **Binary files are not portable by default.** The stored bytes depend on integer size, byte order and struct padding. A file written on one machine may read incorrectly on another. Portable binary needs fixed-width types (`int32_t`), explicit byte order, and no padding.
- **Text files are portable and inspectable** but slower and larger for numbers, and they cannot be updated in place when record lengths vary.
- **Recommendation.** Use **text** for donor records: variable-length names and phones, sequential reading, and value for manual inspection and recovery. Use **binary** for stock and any other data with fixed-size records and frequent random updates. Binary should use fixed-width types if it is shared between machines.

## B4 – Final engineering decision

### B4.1 Implementation and measurement

`add_donor` was completed with the `tmp` pattern and capacity doubling. Its output matches the expected output:

```
added 7001 (O+): size = 1, capacity = 2
added 7002 (A+): size = 2, capacity = 2
added 7003 (B-): size = 3, capacity = 4
added 7004 (AB+): size = 4, capacity = 4
added 7005 (O-): size = 5, capacity = 8
```

The report program has two modes, both over a binary file of **100,000 donors**. That is 100 times a present population of 1,000, which is an assumed baseline.

| Mode | Donors | Eligible in next 7 days | Time | Peak RSS |
|---|---|---|---|---|
| `load` (growable list, all donors in memory) | 100,000 | 70,337 | 0.0014 to 0.0022 s | about 3.1 MB |
| `stream` (one record in memory at a time) | 100,000 | 70,337 | 0.0010 to 0.0014 s | about 1.8 MB |

Both modes give the same count, which checks correctness. The 1,000-donor run gives 707 eligible under the same rule.

### B4.2 Memory safety

The `load` and `stream` modes were built with `-fsanitize=address,undefined` and run on the full file. Both exited with status 0 and LeakSanitizer reported no leaks, which confirms that every block allocated by the growable list is freed. Valgrind's summary (requested) is not available here.

### B4.3 Production decision

**Decision: stream the nightly report.** It uses about 1.3 MB less peak memory and is slightly faster, because it skips building and freeing the list. The report needs one pass and one count, so it does not benefit from holding the list in memory.

**Keep the growable list for interactive use.** Operations that need many lookups per run (for example a search that touches the same donors repeatedly) benefit from the list. At 100,000 donors (about 1.6 MB of records) keeping everything in memory is comfortably within reach, so the limit is not reached at the district scale stated in the case study.

**Index file only if lookups by ID are needed at much larger scale.** A separate sorted index with `fseek`-based binary search costs O(log n) file reads per lookup and O(1) memory. It becomes worthwhile when the donor file is too large to load (many millions of records) or when lookups are rare. It is not needed for a nightly report.

Summary: at the measured scale the in-memory list is cheap, so memory is not the constraint. The stream mode is the better default for a batch report because it is simplest and uses the least memory. The list should be kept for interactive work, and an index file considered only if the data grows by orders of magnitude.

---

## Summary of engineering conclusions

- Keep functions small and pass data through parameters and return values, not globals. This keeps them testable and reusable with no measurable cost.
- Recursion is clear for divide-and-conquer and tiny depths. Linear recursion hits a stack limit at about 262,000 frames here, so loops are the safer choice for data-sized depths.
- Never reuse a pointer across a call that might `realloc`. Return indices or refetch.
- Use `tmp` for every `realloc`, and free through one owner.
- Use the bounded `fgets` for input and check every file operation with `perror`.
- Use binary with fixed-width records for data that is updated in place. Use text for variable-length, sequentially read data.
- Measure before choosing: the in-place binary update is about 2,000 times faster than a text rewrite at 100,000 donors, and the streamed report uses less memory than the in-memory list.
