#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static const char *GROUPS[] = {"A+","A-","B+","B-","AB+","AB-","O+","O-"};
static int valid_group(const char *g)
{
 for (int i = 0; i < 8; i++) if (strcmp(g, GROUPS[i]) == 0) return 1;
 return 0;
}
int main(int argc, char *argv[])
{
 if (argc != 3) {
 fprintf(stderr, "usage: %s <find|issue> <blood-group>\n", argv[0]);
 return 2;
 }
 if (strcmp(argv[1], "find") != 0 && strcmp(argv[1], "issue") != 0) {
 fprintf(stderr, "error: unknown command '%s'\n", argv[1]);
 return 2;
 }
 if (!valid_group(argv[2])) {
 fprintf(stderr, "error: invalid blood group '%s'\n", argv[2]);
 return 2;
 }
 printf("command=%s group=%s\n", argv[1], argv[2]);
 return 0;
}
