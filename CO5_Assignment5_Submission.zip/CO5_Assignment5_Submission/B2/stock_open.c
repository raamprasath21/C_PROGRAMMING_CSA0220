#include <stdio.h>
#include <stdlib.h>
/* Opens the binary stock file; reports the cause with perror() and exits cleanly. */
int main(int argc, char *argv[])
{
 if (argc != 2) { fprintf(stderr, "usage: %s <stock-file>\n", argv[0]); return 2; }
 FILE *fp = fopen(argv[1], "rb+");
 if (fp == NULL) { perror(argv[1]); return 1; }
 printf("opened %s\n", argv[1]);
 fclose(fp);
 return 0;
}
