#include <stdio.h>
/* Donor name buffer holds 16 bytes (15 characters + '\0'). */
int main(void)
{
 char name[16];
 printf("Enter donor name: ");
 scanf("%s", name); /* no width limit: unsafe */
 printf("Stored name: %s\n", name);
 return 0;
}
