#include <stdio.h>
#include <string.h>
/* Donor name buffer holds 16 bytes (15 characters + '\0'). */
int main(void)
{
 char name[16];
 printf("Enter donor name: ");
 if (fgets(name, sizeof name, stdin) == NULL) { fprintf(stderr, "no input\n"); return 1; }
 size_t len = strlen(name);
 if (len > 0 && name[len - 1] == '\n') {
 name[len - 1] = '\0';
 } else {
 /* line was longer than the buffer: discard the rest of it */
 int c; while ((c = getchar()) != '\n' && c != EOF) ;
 printf("(input truncated to %zu characters)\n", strlen(name));
 }
 printf("Stored name: %s\n", name);
 return 0;
}
