#include <stdio.h>
#include <stdlib.h>
/* Iterative square-and-multiply: no recursion, so no stack growth. Base 1 avoids overflow. */
long long power_iter(long long base, int exp)
{
 long long result = 1;
 while (exp > 0) {
 if (exp & 1) result *= base;
 base *= base;
 exp >>= 1;
 }
 return result;
}
int main(int argc, char **argv)
{
 int n = atoi(argv[1]);
 printf("iterative n=%d -> %lld (completed)\n", n, power_iter(1, n));
 return 0;
}
