#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long long calls = 0;

long long power_linear(long long base, int exp)
{
 calls++;
 if (exp == 0) return 1;
 return base * power_linear(base, exp - 1);
}

long long power_fast(long long base, int exp)
{
 calls++;
 if (exp == 0) return 1;
 long long half = power_fast(base, exp / 2);
 if (exp % 2 == 0) return half * half;
 return base * half * half;
}

/* Variant from the task: two independent recursive calls (no reuse). */
long long power_fast_twice(long long base, int exp)
{
 calls++;
 if (exp == 0) return 1;
 long long r = power_fast_twice(base, exp / 2) * power_fast_twice(base, exp / 2);
 if (exp % 2 == 1) r *= base;
 return r;
}

long long power_iter(long long base, int exp)
{
 long long result = 1;
 while (exp > 0) {
 if (exp & 1) result *= base;
 base *= base;
 exp >>= 1;
 }
 return result;
}

static int check(const char *name, long long got, long long want)
{
 int ok = got == want;
 printf("  %-34s got %-12lld want %-12lld %s\n", name, got, want, ok ? "PASS" : "FAIL");
 return ok;
}

int main(void)
{
 int fails = 0;
 printf("B1.1 Validation\n");
 fails += !check("linear 2^10 (ordinary)", power_linear(2, 10), 1024);
 fails += !check("fast 2^10 (ordinary)", power_fast(2, 10), 1024);
 fails += !check("fast 3^5 odd exponent", power_fast(3, 5), 243);
 fails += !check("fast 0^0 (exp = 0)", power_fast(0, 0), 1);
 fails += !check("fast 0^7", power_fast(0, 7), 0);
 fails += !check("fast 1^1000000 (exp = 1 path)", power_fast(1, 1), 1);
 fails += !check("fast 7^1 (exp = 1)", power_fast(7, 1), 7);
 fails += !check("fast 5^13 (mixed bits)", power_fast(5, 13), 1220703125LL);
 fails += !check("linear 9^0 (base case)", power_linear(9, 0), 1);
 fails += !check("iter 2^62", power_iter(2, 62), 1LL << 62);
 printf("  result: %s (%d failures)\n\n", fails ? "FAILURES" : "all passed", fails);

 printf("B1.3 Call counts (exponent n, base 1 to keep values small)\n");
 printf("  %-8s %-14s %-14s %-18s %-14s\n", "n", "linear", "halving", "halving x2 calls", "recurrence");
 int ns[] = {10, 100, 1000, 10000};
 for (int i = 0; i < 4; i++) {
 int n = ns[i];
 calls = 0; power_linear(1, n); long long cl = calls;
 calls = 0; power_fast(1, n); long long cf = calls;
 calls = 0; power_fast_twice(1, n); long long ct = calls;
 int depth = 0; for (int m = n; m > 0; m /= 2) depth++;
 printf("  %-8d %-14lld %-14lld %-18lld linear=%d, halving=%d\n", n, cl, cf, ct, n + 1, depth + 1);
 }
 return 0;
}
