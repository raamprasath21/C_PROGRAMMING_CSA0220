#include <stdio.h>
#include <stdlib.h>
long long power_linear(long long base, int exp)
{
 if (exp == 0) return 1;
 return base * power_linear(base, exp - 1);
}
int main(int argc, char **argv)
{
 int n = atoi(argv[1]);
 volatile long long r = power_linear(1, n); /* base 1: no overflow */
 printf("ok n=%d\n", n);
 return 0;
}
